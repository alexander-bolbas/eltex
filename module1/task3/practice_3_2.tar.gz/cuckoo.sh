#!/bin/bash

PIPE=/tmp/run/cuckoo.pid
LOG=~/cuckoo.log

mkdir -p /tmp/run
rm -f "$PIPE"
mkfifo "$PIPE"

echo "$(date '+%Y-%m-%d %H:%M:%S') Startup!" >> "$LOG"

cleanup() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') Shutdown!" >> "$LOG"
    rm -f "$PIPE"
    exit 0
}

trap cleanup SIGUSR1

while true; do
    # Читать из канала (ждать сообщения)
    if read -r line < "$PIPE"; then
        # Проверить формат: NAME[PID]: how much time do I have?
        if echo "$line" | grep -qE '^[^[]+\[[0-9]+\]: how much time do I have\?$'; then
            NAME=$(echo "$line" | sed 's/\[.*//')
            PID=$(echo  "$line" | sed 's/.*\[\([0-9]*\)\].*/\1/')
            # Случайное число от 2 до 10
            N=$(( RANDOM % 9 + 2 ))
            echo "$(date '+%Y-%m-%d %H:%M:%S') $NAME[$PID] $N" >> "$LOG"
            # Записать ответ в файл ответа для конкретного PID
            echo "$N" > /tmp/run/cuckoo_${PID}.resp
        fi
    fi
done
