#!/bin/bash

SCRIPT_NAME=$(basename "$0")
PIPE=/tmp/run/cuckoo.pid
PID=$$

if [ "$SCRIPT_NAME" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

LOG="${SCRIPT_NAME%.sh}.log"

echo "$(date '+%Y-%m-%d %H:%M:%S') [$PID] Скрипт запущен" >> "$LOG"

if [ ! -p "$PIPE" ]; then
    echo "cuckoo не запущен, жду 5 секунд по умолчанию"
    sleep 5
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$PID] Скрипт завершился, работал 5 секунд." >> "$LOG"
    exit 0
fi

echo "${SCRIPT_NAME}[$PID]: how much time do I have?" > "$PIPE"

RESP_FILE="/tmp/run/cuckoo_${PID}.resp"
N=5
for i in $(seq 1 10); do
    if [ -f "$RESP_FILE" ]; then
        N=$(cat "$RESP_FILE")
        rm -f "$RESP_FILE"
        break
    fi
    sleep 1
done

sleep "$N"

echo "$(date '+%Y-%m-%d %H:%M:%S') [$PID] Скрипт завершился, работал $N секунд." >> "$LOG"
