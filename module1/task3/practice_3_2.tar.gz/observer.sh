#!/bin/bash

CONFIG=~/observer.conf
LOG=~/observer.log

while IFS= read -r script_path; do
    # Пропустить пустые строки и комментарии
    [ -z "$script_path" ] && continue
    [ "${script_path:0:1}" = "#" ] && continue

    script_name=$(basename "$script_path")
    running=false

    # Проверить наличие в /proc (поиск по cmdline)
    for pid_dir in /proc/[0-9]*/; do
        cmdline_file="${pid_dir}cmdline"
        if [ -r "$cmdline_file" ]; then
            if tr '\0' ' ' < "$cmdline_file" 2>/dev/null | grep -q "$script_name"; then
                running=true
                break
            fi
        fi
    done

    # Если не запущен — запустить через nohup
    if ! $running; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') Restarting: $script_name" >> "$LOG"
        nohup bash "$script_path" >> /dev/null 2>&1 &
    fi

done < "$CONFIG"
